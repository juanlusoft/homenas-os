#!/usr/bin/env bash
set -euo pipefail

SERVICE_NAME="homenas-frontend-lite.service"
APP_DIR="/opt/homenas-frontend-lite"

if [[ $EUID -ne 0 ]]; then
  echo "Please run as root (sudo)." >&2
  exit 1
fi

echo "🛑 Stopping service..."
systemctl stop "$SERVICE_NAME" || true
systemctl disable "$SERVICE_NAME" || true

echo "🧹 Removing service unit..."
rm -f /etc/systemd/system/"$SERVICE_NAME"
systemctl daemon-reload

echo "🗑️ Removing app directory $APP_DIR ..."
rm -rf "$APP_DIR"

echo "🗒️ Removing env file..."
rm -f /etc/default/homenas-frontend-lite

echo "✅ Uninstalled HomeNAS Frontend Lite."
