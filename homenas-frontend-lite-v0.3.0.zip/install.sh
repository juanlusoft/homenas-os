#!/usr/bin/env bash
set -euo pipefail

APP_DIR="/opt/homenas-frontend-lite"
VENV_DIR="$APP_DIR/venv"
PORT="${PORT:-9080}"

if [[ $EUID -ne 0 ]]; then
  echo "Please run as root (sudo)." >&2
  exit 1
fi

echo "🔧 Updating apt and installing dependencies..."
apt-get update -y
DEBIAN_FRONTEND=noninteractive apt-get install -y \      python3-venv python3-pip smartmontools jq \      btrfs-progs samba samba-common samba-common-bin parted lshw pciutils nvme-cli

echo "📁 Creating application directory at $APP_DIR ..."
mkdir -p "$APP_DIR"
cp -r api "$APP_DIR/"
cp -r ui "$APP_DIR/"
chmod -R 755 "$APP_DIR"

echo "🐍 Creating Python virtual environment..."
python3 -m venv "$VENV_DIR"
source "$VENV_DIR/bin/activate"
pip install --upgrade pip
pip install fastapi uvicorn[standard] psutil

echo "🧩 Installing systemd service..."
cat >/etc/systemd/system/homenas-frontend-lite.service <<'UNIT'
[Unit]
Description=HomeNAS Frontend Lite API
After=network-online.target
Wants=network-online.target

[Service]
WorkingDirectory=/opt/homenas-frontend-lite
ExecStart=/opt/homenas-frontend-lite/venv/bin/uvicorn api.main:app --host 0.0.0.0 --port 9080
Restart=on-failure
User=root
Group=root

[Install]
WantedBy=multi-user.target
UNIT

systemctl daemon-reload
systemctl enable --now homenas-frontend-lite.service

echo "✅ Done. Open: http://<IP>:$PORT"
