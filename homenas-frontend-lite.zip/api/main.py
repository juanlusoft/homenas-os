from fastapi import FastAPI, HTTPException
from fastapi.responses import FileResponse
from fastapi.middleware.cors import CORSMiddleware
import subprocess, json, os, platform, psutil

APP_DIR = os.environ.get("APP_DIR", os.path.dirname(__file__))
UI_DIR = os.path.join(os.path.dirname(APP_DIR), "ui")

app = FastAPI(title="HomeNAS Frontend Lite", version="0.1.1")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

def run_cmd(cmd):
    try:
        p = subprocess.run(cmd, capture_output=True, text=True, check=False)
        return (p.returncode, p.stdout.strip(), p.stderr.strip())
    except Exception as e:
        return (1, "", str(e))

@app.get("/api/system")
def system_info():
    try:
        cpu = platform.processor() or platform.machine()
        vm = psutil.virtual_memory()
        disks_usage = []
        for p in psutil.disk_partitions(all=False):
            try:
                u = psutil.disk_usage(p.mountpoint)
                disks_usage.append({"mountpoint": p.mountpoint, "fstype": p.fstype, "total": u.total, "used": u.used})
            except Exception:
                pass
        return {
            "hostname": platform.node(),
            "os": f"{platform.system()} {platform.release()}",
            "python": platform.python_version(),
            "cpu": cpu,
            "arch": platform.machine(),
            "load": os.getloadavg() if hasattr(os, "getloadavg") else [0,0,0],
            "ram": {"total": vm.total, "used": vm.used},
            "disks_usage": disks_usage,
            "net_if": list(psutil.net_if_addrs().keys()),
        }
    except Exception as e:
        raise HTTPException(500, str(e))

@app.get("/api/disks")
def list_disks():
    code, out, err = run_cmd(["lsblk", "-J", "-o", "NAME,SIZE,MODEL,TYPE,MOUNTPOINT,FSTYPE,UUID,RM,RO,STATE,PKNAME"])
    if code != 0:
        raise HTTPException(500, f"lsblk failed: {err}")
    data = json.loads(out)
    return data

@app.get("/api/disks/smart/{device}")
def smart_health(device: str):
    devpath = f"/dev/{device}"
    if not os.path.exists(devpath):
        raise HTTPException(404, f"{devpath} not found")
    code, out, err = run_cmd(["smartctl", "-H", devpath])
    if code != 0 and "SMART support is: Unavailable" in out+err:
        return {"device": device, "supported": False, "health": "unknown"}
    return {"device": device, "supported": True, "raw": out}

@app.get("/api/btrfs/list")
def btrfs_list():
    pools = []
    code, out, err = run_cmd(["btrfs", "filesystem", "show"])
    if code == 0:
        pools.append({"filesystem_show": out})
    mounts = [p.mountpoint for p in psutil.disk_partitions() if p.fstype == "btrfs"]
    stats = {}
    for m in mounts:
        c, o, e = run_cmd(["btrfs", "device", "stats", m])
        stats[m] = o if c == 0 else e
    return {"pools": pools, "stats": stats, "mounts": mounts}

@app.post("/api/btrfs/mkfs")
def btrfs_mkfs(devices: list[str], label: str = "homenas", raid: str = "single", force: bool = False, actually_make: bool = False):
    if not devices:
        raise HTTPException(400, "devices list is empty")
    for d in devices:
        if not os.path.exists(d):
            raise HTTPException(400, f"Device {d} not found")

    profiles = {
        "single": [],
        "raid0": ["-d", "raid0", "-m", "raid0"],
        "raid1": ["-d", "raid1", "-m", "raid1"],
        "raid10": ["-d", "raid10", "-m", "raid10"],
        "raid5": ["-d", "raid5", "-m", "raid5"],
        "raid6": ["-d", "raid6", "-m", "raid6"],
    }
    profile = profiles.get(raid, [])
    cmd = ["mkfs.btrfs", "-L", label] + profile
    if force:
        cmd += ["-f"]
    cmd += devices

    if not actually_make:
        return {"cmd": " ".join(cmd), "note": "Dry preview. Set actually_make=true to run."}

    code, out, err = run_cmd(cmd)
    if code != 0:
        raise HTTPException(500, f"mkfs.btrfs failed: {err or out}")
    return {"ok": True, "output": out}

@app.get("/api/smb/shares")
def smb_shares():
    conf = "/etc/samba/smb.conf"
    shares = []
    if os.path.exists(conf):
        with open(conf, "r", encoding="utf-8", errors="ignore") as f:
            current = None
            for line in f:
                line = line.strip()
                if line.startswith("[") and line.endswith("]"):
                    name = line.strip("[]")
                    if name.lower() != "global":
                        current = {"name": name, "params": {}}
                        shares.append(current)
                elif "=" in line and current:
                    k, v = [x.strip() for x in line.split("=", 1)]
                    current["params"][k] = v
    return {"shares": shares}

@app.post("/api/smb/add")
def smb_add_share(name: str, path: str, guest_ok: bool = True, read_only: bool = False):
    if not os.path.isdir(path):
        raise HTTPException(400, f"path {path} is not a directory")
    conf = "/etc/samba/smb.conf"
    stanza = (
        f"\\n[{name}]\\n"
        f"   path = {path}\\n"
        f"   browseable = yes\\n"
        f"   read only = {'yes' if read_only else 'no'}\\n"
        f"   guest ok = {'yes' if guest_ok else 'no'}\\n"
        f"   create mask = 0664\\n"
        f"   directory mask = 0775\\n"
    )
    try:
        with open(conf, "a") as f:
            f.write(stanza)
    except PermissionError:
        raise HTTPException(403, "Not permitted to edit smb.conf; run service with sufficient permissions.")
    code, out, err = run_cmd(["systemctl", "restart", "smbd"])
    if code != 0:
        raise HTTPException(500, f"Failed to restart smbd: {err or out}")
    return {"ok": True, "name": name, "path": path}

@app.get("/{path:path}")
def serve_ui(path: str):
    file_path = os.path.join(UI_DIR, path if path else "index.html")
    if os.path.isdir(file_path) or not os.path.exists(file_path):
        file_path = os.path.join(UI_DIR, "index.html")
    return FileResponse(file_path)
